﻿using System;

namespace Tetris
{
    public class BlockReihe
    {
        private readonly Block[] Blöcke = new Block[]
        {
            new IBlock(),
            new JBlock(),
            new LBlock(),
            new OBlock(),
            new SBlock(),
            new TBlock(),
            new ZBlock(),
        };

        private readonly Random random = new Random();

        public Block NächsterBlock { get; private set; }

        public BlockReihe()
        {
            NächsterBlock = RandomBlock();
        }
        private Block RandomBlock()
        {
            return Blöcke[random.Next(Blöcke.Length)];  
        }

        public Block HoleUndUpdate()
        {
            Block block = NächsterBlock;

            do
            {
                NächsterBlock = RandomBlock();
            }
            while (block.ID == NächsterBlock.ID);

            return block;
        }
    }
}
