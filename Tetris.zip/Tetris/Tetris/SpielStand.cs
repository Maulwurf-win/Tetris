﻿using System.Runtime.ExceptionServices;

namespace Tetris
{
    public class SpielStand
    {
        private Block momentanerBlock;

        public Block MomentanerBlock
        {
            get => momentanerBlock;
            private set
            {
                momentanerBlock = value;
                momentanerBlock.Zurücksetzen();

                for (int i = 0; i < 2; i++)
                {
                    momentanerBlock.Bewegung(1, 0);

                    if (!BlockPasst())
                    {
                        momentanerBlock.Bewegung(-1, 0);
                    }
                }
            }
        }

        public GameGrid GameGrid { get; }
        public BlockReihe BlockReihe { get; }
        public bool GameOver { get; private set; }
        public int Punktzahl { get; private set; }  
        public Block GehaltenerBlock { get; private set; }
        public bool KannHalten { get; private set; }

        public SpielStand()     
        {
            GameGrid = new GameGrid(22, 10);
            BlockReihe = new BlockReihe();
            MomentanerBlock = BlockReihe.HoleUndUpdate();
            KannHalten = true;
        }

        private bool BlockPasst()
        {
            foreach (Position p in MomentanerBlock.Fliesenposition())
            {
                if (!GameGrid.IstLeer(p.Row, p.Column))
                {
                    return false;
                }
            }

            return true;
        }

        public void HalteBlock()
        {
            if (!KannHalten)
            {
                return;
            }

            if (GehaltenerBlock == null)
            {
                GehaltenerBlock = MomentanerBlock;
                MomentanerBlock = BlockReihe.HoleUndUpdate();
            }
            else
            {
                Block tmp = MomentanerBlock;
                MomentanerBlock = GehaltenerBlock;
                GehaltenerBlock = tmp;
            }
            
            KannHalten = false; 
        }

        public void RotiereBlockUZ()
        {
            MomentanerBlock.RotiereUZ();

            if (!BlockPasst())
            {
                MomentanerBlock.RotiereGUZ();
            }
        }

        public void RotiereBlockGUZ()
        {
            MomentanerBlock.RotiereGUZ();

            if (!BlockPasst())
            {
                MomentanerBlock.RotiereUZ();
            }
        }

        public void BewegeBlockLinks()
        {
            MomentanerBlock.Bewegung(0, -1);

            if (!BlockPasst())
            {
                MomentanerBlock.Bewegung(0, 1);
            }
        }

        public void BewegeBlockRechts()
        {
            MomentanerBlock.Bewegung(0, 1);

            if (!BlockPasst())
            {
                MomentanerBlock.Bewegung(0, -1);
            }
        }

        private bool IstSpielVorbei()
        {
            return !(GameGrid.IstReiheLeer(0) && GameGrid.IstReiheLeer(1));
        }

        private void PlatziereBlock()
        {
            foreach (Position p in MomentanerBlock.Fliesenposition())
            {
                GameGrid[p.Row, p.Column] = MomentanerBlock.ID;
            }

            Punktzahl += GameGrid.BeseitigeGamzeReihen();

            if (IstSpielVorbei())
            {
                GameOver = true;
            }
            else
            {
                MomentanerBlock = BlockReihe.HoleUndUpdate();
                KannHalten = true;
            }
        }

        public void BewegeBlockHerunter()
        {
            MomentanerBlock.Bewegung(1, 0);

            if (!BlockPasst())
            {
                MomentanerBlock.Bewegung(-1, 0);
                PlatziereBlock();
            }
        }

        private int FliesenFallDistanz(Position p)
        {
            int drop = 0;
            
            while (GameGrid.IstLeer(p.Row + drop + 1, p.Column))
            {
                drop++;
            }

            return drop;
        }

        public int BlockFallDistanz()
        {
            int drop = GameGrid.Rows;

            foreach (Position p in MomentanerBlock.Fliesenposition())
            {
                drop = System.Math.Min(drop, FliesenFallDistanz(p));   
            }

            return drop;    
        }

        public void DroppeBlock()
        {
            MomentanerBlock.Bewegung(BlockFallDistanz(), 0);
            PlatziereBlock();
        }
    }
}
