﻿using System.Collections.Generic;

namespace Tetris
{
    public abstract class Block
    {
        protected abstract Position[][] Fliesen { get; } 
        protected abstract Position AnfangsVersatz { get; }
        public abstract int ID { get; }

        private int RotationsStand;
        private Position Versetzung;

        public Block()
        {
            Versetzung = new Position(AnfangsVersatz.Row, AnfangsVersatz.Column);
        }

        public IEnumerable<Position> Fliesenposition()
        {
            foreach (Position p in Fliesen[RotationsStand]) 
            {
                yield return new Position(p.Row + Versetzung.Row, p.Column + Versetzung.Column);
            }
        }

        public void RotiereUZ()
        {
            RotationsStand = (RotationsStand + 1) % Fliesen.Length;
        }

        public void RotiereGUZ()
        {
            if (RotationsStand == 0)
            {
                RotationsStand = Fliesen.Length - 1;
            }
            else
            {
                RotationsStand--;
            }
        }
        
        public void Bewegung(int rows, int columns)
        {
            Versetzung.Row += rows;
            Versetzung.Column += columns;
        }

        public void Zurücksetzen()
        {
            RotationsStand = 0;
            Versetzung.Row = AnfangsVersatz.Row;
            Versetzung.Column = AnfangsVersatz.Column;
        }
    }
}
