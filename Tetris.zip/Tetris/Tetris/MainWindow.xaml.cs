﻿using System;
using System.Net.Mail;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Input;
using System.Threading.Tasks;

namespace Tetris
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly ImageSource[] fliesenBilder = new ImageSource[]
        {
            new BitmapImage(new Uri("Assets/TileEmpty.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileCyan.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileBlue.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileOrange.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileYellow.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileGreen.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TilePurple.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileRed.png", UriKind.Relative)),
        };

        private readonly ImageSource[] blockBilder = new ImageSource[]
        {
            new BitmapImage(new Uri("Assets/Block-Empty.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-I.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-J.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-L.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-O.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-S.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-T.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-Z.png", UriKind.Relative)),
        };

        private readonly Image[,] imageControls;
        private readonly int maxVerzögerung = 1000;
        private readonly int minVerzögerung = 75;
        private readonly int VerzögerungVerringern = 25;

        private SpielStand spielStand = new SpielStand();
        public MainWindow()
        {
            InitializeComponent();
            imageControls = SetupGameCanvas(spielStand.GameGrid);
        }

        private Image[,] SetupGameCanvas(GameGrid grid)
        {
            Image[,] imageControls = new Image[grid.Rows, grid.Columns];
            int cellSize = 25;

            for (int r = 0; r < grid.Rows; r++)
            {
                for (int c = 0; c < grid.Columns; c++)
                {
                    Image imageControl = new Image
                    {
                        Width = cellSize,
                        Height = cellSize,
                    };

                    Canvas.SetTop(imageControl, (r-2) * cellSize + 10);
                    Canvas.SetLeft(imageControl, c * cellSize);
                    GameCanvas.Children.Add(imageControl);
                    imageControls[r, c] = imageControl;
                }
            }

            return imageControls;
        }

        private void DrawGrid(GameGrid grid)
        {
            for (int r = 0; r < grid.Rows; r++)
            {
                for (int c = 0; c < grid.Columns; c++)
                {
                    int ID = grid[r, c];
                    imageControls[r, c].Opacity = 1;
                    imageControls[r, c].Source = fliesenBilder[ID];
                }
            }
        }

        private void DrawBlock(Block block)
        {
            foreach (Position p in block.Fliesenposition())
            {
                imageControls[p.Row, p.Column].Opacity = 1;
                imageControls[p.Row, p.Column].Source = fliesenBilder[block.ID];
            }
        }

        private void DrawNextBlock(BlockReihe blockReihe)
        {
            Block next = blockReihe.NächsterBlock;
            NextImage.Source = blockBilder[next.ID];
        }

        private void DrawHeldBlock(Block gehaltenerBlock)
        {
            if (gehaltenerBlock == null)
            {
                HoldImage.Source = blockBilder[0];
            }
            else
            {
                HoldImage.Source = blockBilder[gehaltenerBlock.ID];
            }
        }

        private void DrawGhostBlock(Block block)
        {
            int dropDistance = spielStand.BlockFallDistanz();

            foreach (Position p in block.Fliesenposition())
            {
                imageControls[p.Row + dropDistance, p.Column].Opacity = 0.25;
                imageControls[p.Row + dropDistance, p.Column].Source = fliesenBilder[block.ID];
            }
        }
        private void Draw(SpielStand spielStand)
        {
            DrawGrid(spielStand.GameGrid);
            DrawGhostBlock(spielStand.MomentanerBlock);
            DrawBlock(spielStand.MomentanerBlock);
            DrawNextBlock(spielStand.BlockReihe);
            DrawHeldBlock(spielStand.GehaltenerBlock);
            ScoreText.Text = $"Punktzahl: {spielStand.Punktzahl}";
        }

        private async Task GameLoop()
        {
            Draw(spielStand);

            while (!spielStand.GameOver)
            {
                int verzögerung = Math.Max(minVerzögerung, maxVerzögerung - (spielStand.Punktzahl * VerzögerungVerringern));
                await Task.Delay(500);
                spielStand.BewegeBlockHerunter();
                Draw(spielStand);
            }

            GameOverMenu.Visibility = Visibility.Visible;
            FinalScoreText.Text = $"Punktzahl: {spielStand.Punktzahl}";
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
           if (spielStand.GameOver)
            {
                return;
            }

           switch (e.Key)
            {
                case Key.Left or Key.A:
                    spielStand.BewegeBlockLinks();
                    break;
                case Key.Right or Key.D:
                    spielStand.BewegeBlockRechts();
                    break;
                case Key.Down or Key.S:
                    spielStand.BewegeBlockHerunter();
                    break;
                case Key.Up or Key.E or Key.U:
                    spielStand.RotiereBlockUZ();
                    break;
                case Key.L or Key.Q or Key.G:
                    spielStand.RotiereBlockGUZ();
                    break;
                case Key.C or Key.P or Key.H:
                    spielStand.HalteBlock();
                    break;
                case Key.Space:
                    spielStand.DroppeBlock();
                    break; 
                default:
                    return;
            }

            Draw(spielStand);
        }   

        private async void GameCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            await GameLoop();
        }

        private async void PlayAgain_Click(object sender, RoutedEventArgs e)
        {
            spielStand = new SpielStand();
            GameOverMenu.Visibility = Visibility.Hidden;
            await GameLoop();
        }
    }
}
